package com.example.ss.adapters;

public class User {

	public long uid;
	public String name;
	public String logo;
	public String time;
	public String sign;
}
